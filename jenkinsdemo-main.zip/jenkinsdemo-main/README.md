# Jenkins Pipeline Demo
In this video I am going to show you how to install jenkins on a Linux 2023 machine and then create a Jenkins pipeline
that is going to create some infrastructure in AWS.
You can use this as a starting point for any of your project and build on it for further enhancements

